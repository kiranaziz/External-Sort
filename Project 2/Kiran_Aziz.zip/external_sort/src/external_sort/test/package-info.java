/**
 * Provides classes for testing implementations in the {@code external_sort} package.
 * 
 * @author Jeong-Hyon Hwang (jhh@cs.albany.edu)
 */
package external_sort.test;